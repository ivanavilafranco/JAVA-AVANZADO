package tema2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class ImportarClientes {

    public static void main(String[] args) {

        // Carpeta que contiene el fichero y la base de datos.
        String carpeta = "C:/Users/ivana/OneDrive/Escritorio/"
                + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
                + "Tema 2 Base de datos/";

        Path fichero = Paths.get(carpeta, "listado_clientes.txt");

        // Configuramos la conexión con SQLite.
        SQLiteDataSource ds = new SQLiteDataSource();
        ds.setUrl("jdbc:sqlite:" + carpeta + "ejemplo1.db");

        // PreparedStatement: los datos del fichero se asignan a los signos ?.
        String insertar = "INSERT INTO Clientes "
                + "(ID, NOMBRE, APELLIDOS, FECHA_NACIMIENTO, NUM_PEDIDOS) "
                + "VALUES (?, ?, ?, ?, ?)";

        // Statement: esta consulta es fija; no recibe datos del usuario.
        String consultar = "SELECT ID, NOMBRE, APELLIDOS, "
                + "FECHA_NACIMIENTO, NUM_PEDIDOS "
                + "FROM Clientes "
                + "WHERE FECHA_NACIMIENTO < '1978-01-01' "
                + "AND NUM_PEDIDOS > 10";

        int insertados = 0;

        // Los recursos del try se cierran solos al salir del bloque,
        // incluso si se produce un error. También se cierra la conexión.
        try (BufferedReader lector = Files.newBufferedReader(
                    fichero, StandardCharsets.UTF_8);
             Connection conn = ds.getConnection();
             PreparedStatement insertStmt = conn.prepareStatement(insertar);
             Statement selectStmt = conn.createStatement()) {

            String linea;

            // Leemos una línea cada vez del fichero.
            while ((linea = lector.readLine()) != null) {

                if (linea.trim().isEmpty()) {
                    continue;
                }

                // Cada línea tiene 5 campos separados por punto y coma.
                String[] datos = linea.split(";", -1);

                if (datos.length != 5) {
                    System.err.println("Línea incorrecta: " + linea);
                    continue;
                }

                // Asignamos los valores a los cinco signos ? del INSERT.
                insertStmt.setInt(1, Integer.parseInt(datos[0].trim()));
                insertStmt.setString(2, datos[1].trim());
                insertStmt.setString(3, datos[2].trim());
                insertStmt.setString(4, datos[3].trim());
                insertStmt.setInt(5, Integer.parseInt(datos[4].trim()));

                // executeUpdate() ejecuta el INSERT.
                insertStmt.executeUpdate();
                insertados++;
            }

            System.out.println("Clientes insertados: " + insertados);
            System.out.println();
            System.out.println("Clientes nacidos antes de 1978 con más de 10 pedidos:");

            // ResultSet contiene las filas devueltas por el SELECT.
            try (ResultSet rs = selectStmt.executeQuery(consultar)) {
                while (rs.next()) {
                    System.out.println(
                            rs.getInt("ID") + " | "
                            + rs.getString("NOMBRE") + " "
                            + rs.getString("APELLIDOS") + " | "
                            + rs.getString("FECHA_NACIMIENTO") + " | "
                            + rs.getInt("NUM_PEDIDOS") + " pedidos");
                }
            }

        } catch (IOException | SQLException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}