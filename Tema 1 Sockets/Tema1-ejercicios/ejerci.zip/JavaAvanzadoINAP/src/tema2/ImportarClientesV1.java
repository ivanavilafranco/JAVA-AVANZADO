

package tema2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class ImportarClientesV1 {

    public static void main(String[] args) {

        // Carpeta donde están el fichero de texto y la base de datos.
        String carpeta = "C:/Users/ivana/OneDrive/Escritorio/"
                + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
                + "Tema 2 Base de datos/";

        Path fichero = Paths.get(carpeta, "listado_clientes.txt");

        // Configuramos la conexión con ejemplo1.db.
        SQLiteDataSource ds = new SQLiteDataSource();
        ds.setUrl("jdbc:sqlite:" + carpeta + "ejemplo1.db");

        // Los signos ? recibirán los cinco datos de cada línea del fichero.
        String insertar = "INSERT INTO Clientes "
                + "(ID, NOMBRE, APELLIDOS, FECHA_NACIMIENTO, NUM_PEDIDOS) "
                + "VALUES (?, ?, ?, ?, ?)";

        // Consulta final que pide el ejercicio.
        String consultar = "SELECT ID, NOMBRE, APELLIDOS, "
                + "FECHA_NACIMIENTO, NUM_PEDIDOS "
                + "FROM Clientes "
                + "WHERE FECHA_NACIMIENTO < '1978-01-01' "
                + "AND NUM_PEDIDOS > 10";

        int insertados = 0;

        // Al salir del try se cierran automáticamente el fichero,
        // PreparedStatement, Statement y la conexión.
        try (BufferedReader lector = Files.newBufferedReader(
                    fichero, StandardCharsets.UTF_8);
             Connection conn = ds.getConnection();
             PreparedStatement insertStmt = conn.prepareStatement(insertar);
             Statement selectStmt = conn.createStatement()) {

            String linea;

            // Leemos el fichero línea por línea.
            while ((linea = lector.readLine()) != null) {

                // Ignoramos las líneas vacías.
                if (linea.trim().isEmpty()) {
                    continue;
                }

                // Formato esperado:
                // ID;NOMBRE;APELLIDOS;FECHA_NACIMIENTO;NUM_PEDIDOS
                String[] datos = linea.split(";", -1);

                if (datos.length != 5) {
                    System.err.println("Línea incorrecta: " + linea);
                    continue;
                }

                // Asignamos cada dato a su signo ? en el INSERT.
                insertStmt.setInt(1, Integer.parseInt(datos[0].trim()));
                insertStmt.setString(2, datos[1].trim());
                insertStmt.setString(3, datos[2].trim());
                insertStmt.setString(4, datos[3].trim());
                insertStmt.setInt(5, Integer.parseInt(datos[4].trim()));

                // Insertamos el cliente en la tabla.
                insertStmt.executeUpdate();
                insertados++;
            }

            System.out.println("Clientes insertados: " + insertados);
            System.out.println();
            System.out.println(
                    "Clientes nacidos antes del 01/01/1978 "
                    + "con más de 10 pedidos:");

            // Ejecutamos la consulta y recorremos sus resultados.
            // ResultSet también se cierra automáticamente.
            try (ResultSet rs = selectStmt.executeQuery(consultar)) {

                while (rs.next()) {
                    System.out.println(
                            rs.getInt("ID") + " | "
                            + rs.getString("NOMBRE") + " "
                            + rs.getString("APELLIDOS") + " | "
                            + rs.getString("FECHA_NACIMIENTO") + " | "
                            + rs.getInt("NUM_PEDIDOS") + " pedidos");
                }
            }

        } catch (IOException | SQLException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}