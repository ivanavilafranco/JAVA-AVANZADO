package tema2;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class ImportarClientesV2 {

    public static void main(String[] args) {

        // Carpeta donde están listado_clientes.txt y ejemplo1.db.
        String carpeta = "C:/Users/ivana/OneDrive/Escritorio/"
                + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
                + "Tema 2 Base de datos/";

        Path fichero = Paths.get(carpeta, "listado_clientes.txt");

        SQLiteDataSource ds = new SQLiteDataSource();
        ds.setUrl("jdbc:sqlite:" + carpeta + "ejemplo1.db");

        String insertar = "INSERT INTO Clientes "
                + "(ID, NOMBRE, APELLIDOS, FECHA_NACIMIENTO, NUM_PEDIDOS) "
                + "VALUES (?, ?, ?, ?, ?)";

        String consultar = "SELECT ID, NOMBRE, APELLIDOS, "
                + "FECHA_NACIMIENTO, NUM_PEDIDOS "
                + "FROM Clientes "
                + "WHERE FECHA_NACIMIENTO < '1978-01-01' "
                + "AND NUM_PEDIDOS > 10 "
                + "ORDER BY ID";

        int insertados = 0;

        // Los recursos se cierran automáticamente al salir del try.
        try (BufferedReader lector = Files.newBufferedReader(
                    fichero, StandardCharsets.UTF_8);
             Connection conn = ds.getConnection();
             PreparedStatement insertStmt = conn.prepareStatement(insertar);
             Statement selectStmt = conn.createStatement()) {

            System.out.println("=== DATOS INSERTADOS EN CLIENTES ===");

            String linea;

            // Leemos e insertamos cada cliente del fichero.
            while ((linea = lector.readLine()) != null) {

                if (linea.trim().isEmpty()) {
                    continue;
                }

                // Formato: ID;NOMBRE;APELLIDOS;FECHA_NACIMIENTO;NUM_PEDIDOS
                String[] datos = linea.split(";", -1);

                if (datos.length != 5) {
                    System.err.println("Línea incorrecta: " + linea);
                    continue;
                }

                int id = Integer.parseInt(datos[0].trim());
                String nombre = datos[1].trim();
                String apellidos = datos[2].trim();
                String fechaNacimiento = datos[3].trim();
                int numPedidos = Integer.parseInt(datos[4].trim());

                // Asignamos los valores al PreparedStatement.
                insertStmt.setInt(1, id);
                insertStmt.setString(2, nombre);
                insertStmt.setString(3, apellidos);
                insertStmt.setString(4, fechaNacimiento);
                insertStmt.setInt(5, numPedidos);

                // Insertamos la fila en SQLite.
                insertStmt.executeUpdate();
                insertados++;

                System.out.println(id + " | " + nombre + " " + apellidos
                        + " | " + fechaNacimiento
                        + " | " + numPedidos + " pedidos");
            }

            System.out.println("Total de clientes insertados: " + insertados);
            System.out.println();

            System.out.println("=== CONSULTA FINAL ===");
            System.out.println(
                    "Nacidos antes del 01/01/1978 con más de 10 pedidos:");

            int encontrados = 0;

            // Ejecutamos la consulta y mostramos sus resultados.
            try (ResultSet rs = selectStmt.executeQuery(consultar)) {
                while (rs.next()) {
                    System.out.println(
                            rs.getInt("ID") + " | "
                            + rs.getString("NOMBRE") + " "
                            + rs.getString("APELLIDOS") + " | "
                            + rs.getString("FECHA_NACIMIENTO") + " | "
                            + rs.getInt("NUM_PEDIDOS") + " pedidos");
                    encontrados++;
                }
            }

            System.out.println("Total que cumplen las condiciones: "
                    + encontrados);

        } catch (IOException | SQLException | NumberFormatException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}
