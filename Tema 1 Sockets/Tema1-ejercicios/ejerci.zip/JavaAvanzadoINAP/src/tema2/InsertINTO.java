package tema2;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class InsertINTO {

    public static void main(String[] args) {
        SQLiteDataSource ds = new SQLiteDataSource();

        ds.setUrl(
            "jdbc:sqlite:C:/Users/ivana/OneDrive/Escritorio/"
            + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
            + "Tema 2 Base de datos/ejemplo1.db"
        );

        String sql = "INSERT INTO Personas (NOMBRE, APELLIDOS) "
                   + "VALUES ('MARIA', 'GARCIA')";

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {

            int filasInsertadas = stmt.executeUpdate(sql);
            System.out.println("Filas insertadas: " + filasInsertadas);

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}