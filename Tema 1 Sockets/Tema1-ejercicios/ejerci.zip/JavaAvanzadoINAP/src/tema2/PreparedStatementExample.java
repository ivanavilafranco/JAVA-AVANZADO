package tema2;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.sqlite.SQLiteDataSource;

public class PreparedStatementExample {

    public static void main(String[] args) {
        SQLiteDataSource ds = new SQLiteDataSource();

        ds.setUrl(
            "jdbc:sqlite:C:/Users/ivana/OneDrive/Escritorio/"
            + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
            + "Tema 2 Base de datos/ejemplo1.db"
        );

        String query = "SELECT * FROM Personas "
                     + "WHERE NOMBRE = ? AND APELLIDOS = ?";

        try (Connection conn = ds.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, "María");
            stmt.setString(2, "Gómez Lucea");

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    int id = rs.getInt("ID");
                    String nombre = rs.getString("NOMBRE");
                    String apellidos = rs.getString("APELLIDOS");

                    System.out.println(
                        "Fila: ID = " + id
                        + ", NOMBRE = " + nombre
                        + ", APELLIDOS = " + apellidos
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}
