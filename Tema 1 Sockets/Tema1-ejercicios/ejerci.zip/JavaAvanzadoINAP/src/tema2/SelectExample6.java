package tema2;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class SelectExample6 {

    public static void main(String[] args) {
        SQLiteDataSource ds = new SQLiteDataSource();

        ds.setUrl(
            "jdbc:sqlite:C:/Users/ivana/OneDrive/Escritorio/"
            + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
            + "Tema 2 Base de datos/ejemplo1.db"
        );

        String query = "SELECT * FROM Personas WHERE NOMBRE = 'María' OR APELLIDOS ='Gómez Lucea'";

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                int id = rs.getInt("ID");
                String nombre = rs.getString("NOMBRE");
                String apellidos = rs.getString("APELLIDOS");

                System.out.println(
                    "Fila: ID = " + id
                    + ", NOMBRE = " + nombre
                    + ", APELLIDOS = " + apellidos
                );
            }

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}