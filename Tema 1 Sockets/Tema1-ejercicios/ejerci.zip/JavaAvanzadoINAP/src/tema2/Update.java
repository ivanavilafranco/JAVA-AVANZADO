package tema2;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class Update {

    public static void main(String[] args) {

        // Configuramos la conexión con la base de datos SQLite.
        SQLiteDataSource ds = new SQLiteDataSource();
        ds.setUrl(
                "jdbc:sqlite:C:/Users/ivana/OneDrive/Escritorio/"
                + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
                + "Tema 2 Base de datos/ejemplo1.db"
        );

        // Cambiamos a TERESA el nombre de la persona cuyo ID es 1.
        String sql = "UPDATE Personas SET NOMBRE = 'TERESA' WHERE ID = 1";

        // try-with-resources cierra automáticamente Statement y Connection.
        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {

            int filasActualizadas = stmt.executeUpdate(sql);
            System.out.println("Filas actualizadas: " + filasActualizadas);

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}
		