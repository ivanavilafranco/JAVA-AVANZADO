package tema2;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.sqlite.SQLiteDataSource;

public class UpdateJuan {

    public static void main(String[] args) {
        SQLiteDataSource ds = new SQLiteDataSource();

        ds.setUrl(
            "jdbc:sqlite:C:/Users/ivana/OneDrive/Escritorio/"
            + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
            + "Tema 2 Base de datos/ejemplo1.db"
        );

        String sql = "UPDATE Personas SET NOMBRE = 'PEDRO' "
                   + "WHERE NOMBRE = 'JUAN'";

        try (Connection conn = ds.getConnection();
             Statement stmt = conn.createStatement()) {

            int filasActualizadas = stmt.executeUpdate(sql);
            System.out.println("Filas actualizadas: " + filasActualizadas);

        } catch (SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }
}