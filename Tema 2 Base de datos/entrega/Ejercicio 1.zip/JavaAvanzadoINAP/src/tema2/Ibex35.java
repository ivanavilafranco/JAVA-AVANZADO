package tema2;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Ibex35 {

    public static void main(String[] args) {

        String direccion = "https://taferk.github.io/CursoJavaAvanzado/"
                + "site/ejercicio1_ibex35.html";

        HttpURLConnection conexion = null;

        try {
            // 1. Nos conectamos a la página.
            URL url = new URL(direccion);
            conexion = (HttpURLConnection) url.openConnection();
            conexion.setConnectTimeout(10000);
            conexion.setReadTimeout(10000);

            // 2. Leemos todo el HTML. Añadimos un espacio entre líneas
            // para poder buscar patrones aunque una etiqueta ocupe varias.
            StringBuilder html = new StringBuilder();

            try (BufferedReader lector = new BufferedReader(
                    new InputStreamReader(
                            conexion.getInputStream(), StandardCharsets.UTF_8))) {

                String linea;
                while ((linea = lector.readLine()) != null) {
                    html.append(linea).append(' ');
                }
            }

            // 3. Localizamos el cuerpo de la tabla del IBEX 35.
            Pattern patronTabla = Pattern.compile(
                    "<table\\b[^>]*\\bid\\s*=\\s*['\"]id-listado-acciones['\"]"
                    + "[^>]*>.*?<tbody[^>]*>(.*?)</tbody>",
                    Pattern.CASE_INSENSITIVE);

            Matcher tabla = patronTabla.matcher(html.toString());

            if (!tabla.find()) {
                System.out.println("No se encontró la tabla del IBEX 35.");
                return;
            }

            String cuerpoTabla = tabla.group(1);

            // 4. Recorremos las filas de la tabla.
            Pattern patronFila = Pattern.compile(
                    "<tr\\b[^>]*>(.*?)</tr>",
                    Pattern.CASE_INSENSITIVE);

            Matcher filas = patronFila.matcher(cuerpoTabla);

            // En cada fila buscamos las celdas <td>.
            Pattern patronCelda = Pattern.compile(
                    "<td\\b[^>]*>(.*?)</td>",
                    Pattern.CASE_INSENSITIVE);

            int contador = 0;

            System.out.println("=== ÚLTIMAS COTIZACIONES DEL IBEX 35 ===");

            while (filas.find()) {
                Matcher celdas = patronCelda.matcher(filas.group(1));

                // Primera celda: nombre de la empresa.
                if (!celdas.find()) {
                    continue;
                }
                String nombre = quitarEtiquetas(celdas.group(1)).trim();

                // Segunda celda: última cotización.
                if (!celdas.find()) {
                    continue;
                }
                String ultimo = quitarEtiquetas(celdas.group(1)).trim();

                System.out.println(nombre + " -> " + ultimo);
                contador++;
            }

            System.out.println("Total de empresas encontradas: " + contador);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);

        } finally {
            if (conexion != null) {
                conexion.disconnect();
            }
        }
    }

    // Elimina etiquetas como <span> para dejar solo su texto.
    private static String quitarEtiquetas(String texto) {
        return texto.replaceAll("<[^>]+>", "");
    }
}