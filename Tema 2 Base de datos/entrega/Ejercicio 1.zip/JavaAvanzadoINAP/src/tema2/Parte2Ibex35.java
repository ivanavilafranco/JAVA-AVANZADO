package tema2;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.sqlite.SQLiteDataSource;

public class Parte2Ibex35 {

    public static void main(String[] args) {

        String direccion = "https://taferk.github.io/CursoJavaAvanzado/"
                + "site/ejercicio1_ibex35.html";

        Path baseDatos = Paths.get(
                "C:/Users/ivana/OneDrive/Escritorio/"
                + "CURSO JAVA AVANZADO INAP/repositorios/JAVA-AVANZADO/"
                + "Tema 2 Base de datos/Ibex35.db"
        );

        try {
            // 1. Leer la página y obtener las cotizaciones.
            String html = descargarHtml(direccion);
            List<String[]> cotizaciones = extraerCotizaciones(html);

            System.out.println("Cotizaciones obtenidas de la web: "
                    + cotizaciones.size());

            // Si la lectura falla, no borramos los datos de SQLite.
            if (cotizaciones.size() != 35) {
                System.err.println(
                        "No se obtuvieron los 35 valores. "
                        + "La base de datos no se ha modificado.");
                return;
            }

            // SQLite crea un fichero nuevo si la ruta no existe.
            // Comprobamos que estamos usando la base de datos creada.
            if (!Files.isRegularFile(baseDatos)) {
                System.err.println("No existe: " + baseDatos);
                return;
            }

            // 2. Borrar las filas anteriores.
            // 3. Insertar los 35 valores extraídos.
            int insertadas = guardarCotizaciones(
                    baseDatos, cotizaciones);

            System.out.println("Filas insertadas en COTIZACIONES: "
                    + insertadas);

        } catch (IOException | SQLException e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace(System.err);
        }
    }

    private static String descargarHtml(String direccion)
            throws IOException {

        HttpURLConnection conexion = null;

        try {
            URL url = new URL(direccion);
            conexion = (HttpURLConnection) url.openConnection();
            conexion.setConnectTimeout(10000);
            conexion.setReadTimeout(10000);

            StringBuilder html = new StringBuilder();

            try (BufferedReader lector = new BufferedReader(
                    new InputStreamReader(
                            conexion.getInputStream(),
                            StandardCharsets.UTF_8))) {

                String linea;

                while ((linea = lector.readLine()) != null) {
                    // Cambiamos el salto de línea por un espacio.
                    html.append(linea).append(' ');
                }
            }

            return html.toString();

        } finally {
            if (conexion != null) {
                conexion.disconnect();
            }
        }
    }

    private static List<String[]> extraerCotizaciones(String html) {

        List<String[]> cotizaciones = new ArrayList<String[]>();

        // Localizamos el tbody de la tabla del IBEX 35.
        Pattern patronTabla = Pattern.compile(
                "<table\\b[^>]*\\bid\\s*=\\s*['\"]"
                + "id-listado-acciones['\"][^>]*>"
                + ".*?<tbody[^>]*>(.*?)</tbody>",
                Pattern.CASE_INSENSITIVE);

        Matcher tabla = patronTabla.matcher(html);

        if (!tabla.find()) {
            return cotizaciones;
        }

        Pattern patronFila = Pattern.compile(
                "<tr\\b[^>]*>(.*?)</tr>",
                Pattern.CASE_INSENSITIVE);

        Pattern patronCelda = Pattern.compile(
                "<td\\b[^>]*>(.*?)</td>",
                Pattern.CASE_INSENSITIVE);

        Matcher filas = patronFila.matcher(tabla.group(1));

        while (filas.find()) {

            Matcher celdas = patronCelda.matcher(filas.group(1));

            // Primera columna: nombre de la empresa.
            if (!celdas.find()) {
                continue;
            }
            String nombre = quitarEtiquetas(
                    celdas.group(1)).trim();

            // Segunda columna: última cotización.
            if (!celdas.find()) {
                continue;
            }
            String ultimo = quitarEtiquetas(
                    celdas.group(1)).trim();

            if (!nombre.isEmpty() && !ultimo.isEmpty()) {
                cotizaciones.add(
                        new String[] { nombre, ultimo });
            }
        }

        return cotizaciones;
    }

    private static String quitarEtiquetas(String texto) {
        return texto.replaceAll("<[^>]+>", "");
    }

    private static int guardarCotizaciones(
            Path baseDatos,
            List<String[]> cotizaciones) throws SQLException {

        SQLiteDataSource ds = new SQLiteDataSource();
        ds.setUrl("jdbc:sqlite:" + baseDatos.toString());

        String sqlInsertar =
                "INSERT INTO COTIZACIONES (NOMBRE, ULTIMO) "
                + "VALUES (?, ?)";

        try (Connection conn = ds.getConnection()) {

            // Agrupamos el DELETE y los INSERT en una transacción.
            conn.setAutoCommit(false);

            try (Statement borrarStmt = conn.createStatement();
                 PreparedStatement insertarStmt =
                         conn.prepareStatement(sqlInsertar)) {

                // Borramos todos los registros anteriores.
                borrarStmt.executeUpdate(
                        "DELETE FROM COTIZACIONES");

                int insertadas = 0;

                // Insertamos una fila por empresa.
                for (String[] cotizacion : cotizaciones) {
                    insertarStmt.setString(1, cotizacion[0]);
                    insertarStmt.setString(2, cotizacion[1]);

                    insertadas += insertarStmt.executeUpdate();
                }

                // Guardamos todos los cambios.
                conn.commit();

                return insertadas;

            } catch (SQLException e) {
                // Ante un error, recuperamos los datos anteriores.
                try {
                    conn.rollback();
                } catch (SQLException errorRollback) {
                    e.addSuppressed(errorRollback);
                }
                throw e;
            }
        }
    }
}