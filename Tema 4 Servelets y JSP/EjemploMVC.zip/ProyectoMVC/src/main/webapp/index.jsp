<%@ page language="java" contentType="text/html; charset=UTF-8"%>
<html>
<head>
<title>Página inicial</title>
</head>
<body>
	<jsp:forward page="/ClienteController?action=listado" />
</body>
</html>
