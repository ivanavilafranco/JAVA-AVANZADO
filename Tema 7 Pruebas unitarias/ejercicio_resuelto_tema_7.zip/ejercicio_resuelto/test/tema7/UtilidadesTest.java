package tema7;

import static org.junit.jupiter.api.Assertions.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;

class UtilidadesTest {

	SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");

	@Test
	void testUnoEnero() throws ParseException {
		assertEquals(43, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("01/01/2022")));
	}
	
	@Test
	void testDiaAnterior() throws ParseException {
		assertEquals(43, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("07/08/2022")));
	}
	
	@Test
	void testMismoDia() throws ParseException {
		assertEquals(44, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("08/08/2022")));
	}
	
	@Test
	void testDiaSiguiente() throws ParseException {
		assertEquals(44, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("09/08/2022")));
	}
	
	@Test
	void test31Dic() throws ParseException {
		assertEquals(44, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("31/12/2022")));
	}
	
	@Test
	void testDiaAnteriorAnio1() throws ParseException {
		assertEquals(0, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("07/08/1979")));
	}
	
	@Test
	void testMismoDiaAnio1() throws ParseException {
		assertEquals(1, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("08/08/1979")));
	}
	
	@Test
	void testDiaSiguienteAnio1() throws ParseException {
		assertEquals(1, Utilidades.calculaEdad(dateFormat.parse("08/08/1978"), dateFormat.parse("09/08/1979")));
	}

}
